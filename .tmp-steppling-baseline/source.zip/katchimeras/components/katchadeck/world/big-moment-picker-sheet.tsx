import { Pressable, ScrollView, StyleSheet, View } from 'react-native';

import { ThemedText } from '@/components/themed-text';
import { KatchaSheet } from '@/components/katchadeck/ui/katcha-sheet';
import { KatchaSurfacePalette } from '@/constants/katcha-ui';
import type { BigMomentType } from '@/types/home';

// "Mark today as a big moment" — the Big Moment quest. Pick what kind of moment
// it was; it grows a rare landmark on the patch and lifts the day's Chronicle.

type BigMomentOption = { type: BigMomentType; emoji: string; label: string };

const OPTIONS: BigMomentOption[] = [
  { type: 'birthday', emoji: '🎂', label: 'Birthday' },
  { type: 'milestone', emoji: '🗿', label: 'Milestone' },
  { type: 'trip', emoji: '🧳', label: 'Trip' },
  { type: 'firstTime', emoji: '⭐️', label: 'A first' },
  { type: 'achievement', emoji: '🏆', label: 'Achievement' },
  { type: 'anniversary', emoji: '💛', label: 'Anniversary' },
  { type: 'holiday', emoji: '🎏', label: 'Holiday' },
  // Life events — each lights its own celebration keepsake in the Kingdom.
  { type: 'baby', emoji: '👶', label: 'New baby' },
  { type: 'wedding', emoji: '💍', label: 'Wedding' },
  { type: 'graduation', emoji: '🎓', label: 'Graduation' },
  { type: 'newHome', emoji: '🏡', label: 'New home' },
  { type: 'newJob', emoji: '💼', label: 'New job' },
  { type: 'reunion', emoji: '🤗', label: 'Reunion' },
];
const PARCHMENT = KatchaSurfacePalette.parchment;

// Shared emoji/label per big-moment type — reused by the reader (BigMomentSheet)
// and anywhere a big moment is shown. 'celebration' isn't a picker option but can
// arrive from note interpretation, so give it a friendly default too.
export const BIG_MOMENT_META: Record<string, { emoji: string; label: string }> = {
  ...Object.fromEntries(OPTIONS.map((option) => [option.type, { emoji: option.emoji, label: option.label }])),
  celebration: { emoji: '🎉', label: 'Celebration' },
};

type BigMomentPickerSheetProps = {
  onPick: (type: BigMomentType) => void;
  onClose: () => void;
};

export function BigMomentPickerSheet({ onPick, onClose }: BigMomentPickerSheetProps) {
  return (
    <KatchaSheet header={{ eyebrow: 'A big moment', title: 'What made today matter?' }} onRequestClose={() => onClose()} surface="parchment">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        <View style={styles.grid}>
          {OPTIONS.map((option) => (
            <Pressable
              key={option.type}
              onPress={() => onPick(option.type)}
              style={({ pressed }) => [styles.chip, pressed && styles.chipPressed]}>
              <ThemedText style={styles.chipEmoji}>{option.emoji}</ThemedText>
              <ThemedText style={styles.chipLabel} lightColor={PARCHMENT.text} darkColor={PARCHMENT.text}>
                {option.label}
              </ThemedText>
            </Pressable>
          ))}
        </View>
      </ScrollView>
    </KatchaSheet>
  );
}

const styles = StyleSheet.create({
  scroll: { paddingBottom: 2 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, paddingTop: 8 },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    paddingVertical: 10,
    paddingHorizontal: 13,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: PARCHMENT.border,
    backgroundColor: PARCHMENT.subtle,
  },
  chipPressed: { backgroundColor: 'rgba(40,34,60,0.9)' },
  chipEmoji: { fontSize: 16 },
  chipLabel: { fontSize: 13, fontWeight: '700' },
});
