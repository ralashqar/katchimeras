import { useFocusEffect } from '@react-navigation/native';
import { Image } from 'expo-image';
import { Stack } from 'expo-router';
import { useCallback, useMemo, useState } from 'react';
import { Pressable, ScrollView, Share, StyleSheet, View } from 'react-native';

import { ThemedText } from '@/components/themed-text';
import { Lantern } from '@/constants/theme';
import { useHomeScreenState } from '@/hooks/use-home-screen-state';
import { qualityThresholds } from '@/utils/intelligence/quality-registry';
import { QUEST_DEFINITIONS } from '@/utils/quests/definitions';
import { loadDevLastPhotoAnalysis, type DevLastPhotoAnalysis } from '@/utils/dev-photo-analysis';
import { loadDevLastNoteAnalysis, type DevLastNoteAnalysis } from '@/utils/dev-note-analysis';
import {
  FOUNDATION_NOTE_SCHEMA_VERSION,
  FOUNDATION_PHOTO_MIN_COMPATIBLE_SCHEMA_VERSION,
  FOUNDATION_PHOTO_SCHEMA_VERSION,
  foundationSceneAvailability,
} from '@/utils/foundation-scene';

export default function IntelligenceLabScreen() {
  const { selectedDay, personalEntities, cloudIntelligenceEnabled } = useHomeScreenState();
  const memories = selectedDay?.kind === 'day' ? selectedDay.classifiedMemories ?? [] : [];
  const hatchDecision = selectedDay?.kind === 'day' ? selectedDay.creature?.hatchDecision ?? null : null;
  const hatchDecisionJson = useMemo(() => hatchDecision ? JSON.stringify(hatchDecision, null, 2) : '', [hatchDecision]);
  const [lastPhoto, setLastPhoto] = useState<DevLastPhotoAnalysis | null>(() => loadDevLastPhotoAnalysis());
  const [lastNote, setLastNote] = useState<DevLastNoteAnalysis | null>(() => loadDevLastNoteAnalysis());
  const foundationAvailability = foundationSceneAvailability();
  const lastPhotoJson = useMemo(() => lastPhoto ? JSON.stringify(lastPhoto, null, 2) : '', [lastPhoto]);
  const lastNoteJson = useMemo(() => lastNote ? JSON.stringify(lastNote, null, 2) : '', [lastNote]);
  const foundationJournalTraceJson = useMemo(
    () => lastPhoto ? JSON.stringify({
      semanticFrame: lastPhoto.semanticFrame,
      routeTieBreak: lastPhoto.foundationJournalModelTrace,
    }, null, 2) : '',
    [lastPhoto]
  );
  const topLevelPhotoPromptJson = useMemo(
    () => lastPhoto?.foundationRoutingPrompts?.topLevel
      ? JSON.stringify(lastPhoto.foundationRoutingPrompts.topLevel, null, 2)
      : '',
    [lastPhoto]
  );
  const subcategoryPhotoPromptJson = useMemo(
    () => lastPhoto?.foundationRoutingPrompts?.subcategory
      ? JSON.stringify(lastPhoto.foundationRoutingPrompts.subcategory, null, 2)
      : '',
    [lastPhoto]
  );
  const principalPhotoSignal = useMemo(() => {
    const principalKey = lastPhoto?.semanticFrame?.primaryEvidenceKeys[0];
    return principalKey
      ? lastPhoto?.journalEvidence?.signals.find((signal) => signal.id === principalKey) ?? null
      : null;
  }, [lastPhoto]);
  const focusedQuestEvaluation = lastPhoto?.questContext.questId
    ? lastPhoto.questEvaluations.find((evaluation) => evaluation.questId === lastPhoto.questContext.questId) ?? null
    : null;

  useFocusEffect(useCallback(() => {
    setLastPhoto(loadDevLastPhotoAnalysis());
    setLastNote(loadDevLastNoteAnalysis());
  }, []));

  const shareLastPhotoJson = useCallback(() => {
    if (!lastPhotoJson) return;
    void Share.share({ title: 'Katchimeras photo analysis', message: lastPhotoJson });
  }, [lastPhotoJson]);

  const shareLastNoteJson = useCallback(() => {
    if (!lastNoteJson) return;
    void Share.share({ title: 'Katchimeras note analysis', message: lastNoteJson });
  }, [lastNoteJson]);

  const shareFoundationJournalTrace = useCallback(() => {
    if (!foundationJournalTraceJson) return;
    void Share.share({ title: 'Katchimeras Foundation journal trace', message: foundationJournalTraceJson });
  }, [foundationJournalTraceJson]);

  return (
    <>
      <Stack.Screen options={{ title: 'Intelligence Lab' }} />
      <ScrollView contentInsetAdjustmentBehavior="automatic" contentContainerStyle={styles.content}>
        {hatchDecision ? (
          <View style={[styles.card, styles.hatchDecisionCard]}>
            <View style={styles.headingRow}>
              <ThemedText style={styles.title} lightColor={Lantern.moon50} darkColor={Lantern.moon50} selectable>Hatch decision</ThemedText>
              <ThemedText style={styles.provider} lightColor="#A8E2C6" darkColor="#A8E2C6" selectable>{hatchDecision.engineVersion}</ThemedText>
            </View>
            <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              Leader: {hatchDecision.leaderFamilyId} Â· winner: {hatchDecision.winnerFamilyId} Â· {hatchDecision.leaderFamilyId === hatchDecision.winnerFamilyId ? 'leader won' : 'weighted-draw upset'}
            </ThemedText>
            {hatchDecision.candidates.map((candidate) => (
              <ThemedText key={candidate.profileId} style={styles.line} lightColor={candidate.selected ? '#A8E2C6' : Lantern.moon300} darkColor={candidate.selected ? '#A8E2C6' : Lantern.moon300} selectable>
                {candidate.selected ? 'WINNER' : 'FIELD'} {candidate.familyId}/{candidate.skinId} Â· {Math.round(candidate.probability * 100)}% Â· score {candidate.score.toFixed(3)} Â· journal {candidate.contributions.map((item) => `${item.routeKey} ${item.weight}${item.keyMoment ? ' key' : ''}`).join(', ') || 'none'}
              </ThemedText>
            ))}
            <ThemedText style={styles.json} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>{hatchDecisionJson}</ThemedText>
          </View>
        ) : null}
        <View style={[styles.card, foundationAvailability.available ? styles.foundationReady : styles.foundationWarning]}>
          <View style={styles.headingRow}>
            <ThemedText style={styles.title} lightColor={Lantern.moon50} darkColor={Lantern.moon50} selectable>
              Apple on-device intelligence
            </ThemedText>
            <ThemedText
              style={styles.provider}
              lightColor={foundationAvailability.available ? '#A8E2C6' : '#F3B36A'}
              darkColor={foundationAvailability.available ? '#A8E2C6' : '#F3B36A'}
              selectable>
              {foundationAvailability.available ? 'READY' : 'NEEDS ATTENTION'}
            </ThemedText>
          </View>
          <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
            Status: {foundationAvailability.reason}
            {foundationAvailability.locale ? ` · device language ${foundationAvailability.locale}` : ''}
            {foundationAvailability.localeSupported === false ? ' · unsupported by the current model' : ''}
          </ThemedText>
          <ThemedText
            style={styles.line}
            lightColor={foundationAvailability.noteSchemaVersion === FOUNDATION_NOTE_SCHEMA_VERSION ? '#A8E2C6' : '#F3B36A'}
            darkColor={foundationAvailability.noteSchemaVersion === FOUNDATION_NOTE_SCHEMA_VERSION ? '#A8E2C6' : '#F3B36A'}
            selectable>
            Note routing: {foundationAvailability.noteSchemaVersion === FOUNDATION_NOTE_SCHEMA_VERSION
              ? `schema v${FOUNDATION_NOTE_SCHEMA_VERSION} ready`
              : `legacy native build${foundationAvailability.noteSchemaVersion ? ` (schema v${foundationAvailability.noteSchemaVersion})` : ''} · rebuild required`}
          </ThemedText>
          <ThemedText
            style={styles.line}
            lightColor={foundationAvailability.photoSchemaVersion === FOUNDATION_PHOTO_SCHEMA_VERSION ? '#A8E2C6' : '#F3B36A'}
            darkColor={foundationAvailability.photoSchemaVersion === FOUNDATION_PHOTO_SCHEMA_VERSION ? '#A8E2C6' : '#F3B36A'}
            selectable>
            Photo analysis: {foundationAvailability.photoSchemaVersion === FOUNDATION_PHOTO_SCHEMA_VERSION
              ? `enum routing + OCR schema v${FOUNDATION_PHOTO_SCHEMA_VERSION} ready`
              : (foundationAvailability.photoSchemaVersion ?? 0) >= FOUNDATION_PHOTO_MIN_COMPATIBLE_SCHEMA_VERSION
                ? `compatible native schema v${foundationAvailability.photoSchemaVersion} · v${FOUNDATION_PHOTO_SCHEMA_VERSION} rebuild optional`
                : `legacy native build${foundationAvailability.photoSchemaVersion ? ` (schema v${foundationAvailability.photoSchemaVersion})` : ''} · rebuild required`}
          </ThemedText>
          {!foundationAvailability.available ? (
            <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              In Settings → Apple Intelligence &amp; Siri, turn Apple Intelligence on and make sure the iPhone language and Siri language use the same supported language. If they already match, leave the phone charging on Wi-Fi while the model finishes downloading, then restart the app.
            </ThemedText>
          ) : (
            <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              Foundation Models is ready and photo and note interpretation stay on this device.
            </ThemedText>
          )}
          <ThemedText style={styles.line} lightColor="#A8E2C6" darkColor="#A8E2C6">
            Note routing is strict Foundation-only: independent top-level and subcategory passes with greedy sampling and no alternate classifier.
          </ThemedText>
        </View>
        {lastNote ? (
          <View style={[styles.card, styles.lastPhotoCard]}>
            <View style={styles.headingRow}>
              <ThemedText style={styles.title} lightColor={Lantern.moon50} darkColor={Lantern.moon50}>
                Last note analysis
              </ThemedText>
              <ThemedText style={styles.provider} lightColor={lastNote.status === 'classified' || lastNote.status === 'media_fallback' ? '#A8E2C6' : '#F3B36A'} darkColor={lastNote.status === 'classified' || lastNote.status === 'media_fallback' ? '#A8E2C6' : '#F3B36A'}>
                {lastNote.status.replaceAll('_', ' ').toUpperCase()}
              </ThemedText>
            </View>
            <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              Captured: {lastNote.capturedAt} · {lastNote.durationMs}ms · native schema {lastNote.nativeNoteSchemaVersion ?? 'unknown'}
            </ThemedText>
            <ThemedText style={styles.line} lightColor={Lantern.moon50} darkColor={Lantern.moon50} selectable>
              “{lastNote.transcript}”
            </ThemedText>
            <ThemedText style={styles.line} lightColor={lastNote.routingMode === 'foundation_only' ? '#F3B36A' : '#A8E2C6'} darkColor={lastNote.routingMode === 'foundation_only' ? '#F3B36A' : '#A8E2C6'} selectable>
              Routing mode: {lastNote.routingMode === 'foundation_only' ? 'Foundation only' : 'Hybrid'}
            </ThemedText>
            <ThemedText style={styles.line} lightColor={lastNote.fallbackReason ? '#F3B36A' : '#A8E2C6'} darkColor={lastNote.fallbackReason ? '#F3B36A' : '#A8E2C6'} selectable>
              Result: {lastNote.fallbackReason ?? 'valid structured journal route'}
            </ThemedText>
            <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              Atomic route: {lastNote.routeCandidates[0]?.id ?? 'none'} ({lastNote.subcategoryConfidence ?? 'no confidence'})
              {' · '}flow: {lastNote.topLevelFlowId ?? 'none'}
              {' · '}sampling: greedy
            </ThemedText>
            <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              Candidates: {lastNote.routeCandidates.length
                ? lastNote.routeCandidates.map((route) => `${route.id} ${Math.round(route.confidence * 100)}%`).join(' · ')
                : 'none'}
              {lastNote.firstPassDurationMs !== null ? ` · enrichment ${lastNote.firstPassDurationMs}ms` : ''}
              {lastNote.retryDurationMs !== null ? ` · routing ${lastNote.retryDurationMs}ms` : ''}
            </ThemedText>
            <ThemedText style={styles.line} lightColor={Lantern.moon500} darkColor={Lantern.moon500} selectable>
              Development-only trace. It contains the submitted note and stays in local app storage unless you share it.
            </ThemedText>
            <Pressable accessibilityRole="button" onPress={shareLastNoteJson} style={styles.shareButton}>
              <ThemedText style={styles.shareLabel} lightColor={Lantern.ink950} darkColor={Lantern.ink950}>
                Share note JSON
              </ThemedText>
            </Pressable>
            <ThemedText style={styles.json} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              {lastNoteJson}
            </ThemedText>
          </View>
        ) : null}
        {lastPhoto ? (
          <View style={[styles.card, styles.lastPhotoCard]}>
            <View style={styles.headingRow}>
              <ThemedText style={styles.title} lightColor={Lantern.moon50} darkColor={Lantern.moon50}>
                Last photo analysis
              </ThemedText>
              <ThemedText style={styles.provider} lightColor={Lantern.ember300} darkColor={Lantern.ember300}>
                {lastPhoto.questContext.questId ? 'QUEST CAPTURE' : 'PHOTO'}
              </ThemedText>
            </View>
            <Image source={lastPhoto.thumbnailUri} style={styles.photo} contentFit="cover" transition={120} />
            <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              Captured: {lastPhoto.capturedAt} · representation {lastPhoto.classifiedMemory?.photoAnalysis?.representation.kind ?? 'unknown'}
            </ThemedText>
            <ThemedText style={styles.line} lightColor="#A8E2C6" darkColor="#A8E2C6" selectable>
              Journal routing: salience-ranked evidence cluster â†’ Foundation broad flow â†’ independent Foundation child route
            </ThemedText>
            <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              Semantic frame: {lastPhoto.semanticFrame
                ? `${lastPhoto.semanticFrame.stage} Â· ${lastPhoto.semanticFrame.representation.kind}/${lastPhoto.semanticFrame.container.kind} Â· primary ${lastPhoto.semanticFrame.primaryConceptKey ?? 'none'} Â· unresolved ${lastPhoto.semanticFrame.unresolvedFacet} Â· Foundation ${lastPhoto.semanticFrame.foundation.status}`
                : 'not recorded'}
            </ThemedText>
            <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              Foundation passes: {lastPhoto.foundationPasses
                ? `visual ${lastPhoto.foundationPasses.visualAnchor.status} ${lastPhoto.foundationPasses.visualAnchor.durationMs}ms · OCR ${lastPhoto.foundationPasses.ocrEnrichment?.status ?? 'pending'}${lastPhoto.foundationPasses.ocrEnrichment ? ` ${lastPhoto.foundationPasses.ocrEnrichment.durationMs}ms` : ''}`
                : 'no separate Foundation scene pass'}
            </ThemedText>
            <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              Journal route: {lastPhoto.journalClassification
                ? `${lastPhoto.journalClassification.stage}/${lastPhoto.journalClassification.kind} · ${lastPhoto.journalClassification.selected?.id ?? lastPhoto.journalClassification.selectedFlowId ?? 'none'} · top ${lastPhoto.journalClassification.topLevelConfidence ?? 'not run'} · child ${lastPhoto.journalClassification.subcategoryConfidence ?? 'not run'} · source ${lastPhoto.journalClassification.provider} · candidates ${lastPhoto.journalClassification.candidates.map((candidate) => `${candidate.id} ${Math.round(candidate.confidence * 100)}%`).join(', ') || 'none'}`
                : 'not recorded'}
            </ThemedText>
            <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              Essence tags: {lastPhoto.essenceTags.join(' · ') || 'none'}
            </ThemedText>
            <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              Principal salience: {principalPhotoSignal
                ? `${principalPhotoSignal.id} ${principalPhotoSignal.salience.toFixed(3)} · members ${principalPhotoSignal.memberLabels.join(' / ')} · ${principalPhotoSignal.rankReasons.join(', ')}`
                : 'none'}
            </ThemedText>
            <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              Foundation attempts: {lastPhoto.journalClassification
                ? lastPhoto.journalClassification.attempts.map((attempt) => `${attempt.kind}:${attempt.status}${attempt.errorCode ? `(${attempt.errorCode})` : ''}${attempt.durationMs != null ? ` ${attempt.durationMs}ms` : ''}`).join(', ') || 'none'
                : 'not recorded'}
            </ThemedText>
            <ThemedText style={styles.line} lightColor={Lantern.ember300} darkColor={Lantern.ember300} selectable>
              Semantic frame and optional Foundation request/response trace
            </ThemedText>
            <ThemedText style={styles.decisionTitle} lightColor={Lantern.moon50} darkColor={Lantern.moon50} selectable>
              Assembled top-level Foundation prompt
            </ThemedText>
            <ThemedText style={styles.json} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              {topLevelPhotoPromptJson || 'Not recorded for this capture.'}
            </ThemedText>
            <ThemedText style={styles.decisionTitle} lightColor={Lantern.moon50} darkColor={Lantern.moon50} selectable>
              Assembled subcategory Foundation prompt
            </ThemedText>
            <ThemedText style={styles.json} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              {subcategoryPhotoPromptJson || 'Not run or not recorded for this capture.'}
            </ThemedText>
            <View style={styles.traceActions}>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Share Foundation journal request and response JSON"
                disabled={!foundationJournalTraceJson}
                onPress={shareFoundationJournalTrace}
                style={[styles.shareButton, !foundationJournalTraceJson && styles.disabledButton]}>
                <ThemedText style={styles.shareLabel} lightColor={Lantern.ink950} darkColor={Lantern.ink950}>
                  Share request/response JSON
                </ThemedText>
              </Pressable>
            </View>
            <ThemedText style={styles.json} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              {foundationJournalTraceJson}
            </ThemedText>
            <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              Journal OCR: {lastPhoto.journalEnrichment
                ? `${lastPhoto.journalEnrichment.value} ${Math.round(lastPhoto.journalEnrichment.confidence * 100)}%`
                : 'unused or discarded'}
            </ThemedText>
            {focusedQuestEvaluation ? (
              <View style={styles.questDecision}>
                <ThemedText style={styles.decisionTitle} lightColor={decisionColor(focusedQuestEvaluation.decision)} darkColor={decisionColor(focusedQuestEvaluation.decision)} selectable>
                  {focusedQuestEvaluation.questTitle}: {focusedQuestEvaluation.decision.replace('_', ' ')}
                </ThemedText>
                {focusedQuestEvaluation.reasons.map((reason) => (
                  <ThemedText key={reason} style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
                    {reason}
                  </ThemedText>
                ))}
              </View>
            ) : null}
            <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              Raw labels: {lastPhoto.rawVision?.labels?.map((label) => `${label.name} ${Math.round(label.confidence * 100)}%`).join(' · ') || 'none'}
            </ThemedText>
            <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              Scene: {lastPhoto.scene ? `${lastPhoto.scene.source}:${lastPhoto.scene.type} — ${lastPhoto.scene.detail ?? lastPhoto.scene.label}` : 'none'}
            </ThemedText>
            <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              Subjects: {lastPhoto.classifiedMemory?.photoAnalysis?.subjects.map((subject) => `${subject.role}:${subject.canonicalValue} ${Math.round(subject.score * 100)}%`).join(' · ') || 'none'}
            </ThemedText>
            <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              Qualities: {lastPhoto.classifiedMemory?.qualities.map((quality) => `${quality.qualityId} ${Math.round(quality.score * 100)}% ${quality.centrality}/${quality.status}`).join(' · ') || 'none'}
            </ThemedText>
            <ThemedText style={styles.line} lightColor={lastPhoto.consistencyWarnings?.length ? '#F08C8C' : '#A8E2C6'} darkColor={lastPhoto.consistencyWarnings?.length ? '#F08C8C' : '#A8E2C6'} selectable>
              Consistency: {lastPhoto.consistencyWarnings?.join(' | ') || 'all consumers agree'}
            </ThemedText>
            <Pressable accessibilityRole="button" onPress={shareLastPhotoJson} style={styles.shareButton}>
              <ThemedText style={styles.shareLabel} lightColor={Lantern.ink950} darkColor={Lantern.ink950}>
                Share full JSON
              </ThemedText>
            </Pressable>
            <ThemedText style={styles.json} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              {lastPhotoJson}
            </ThemedText>
          </View>
        ) : (
          <View style={styles.empty}>
            <ThemedText lightColor={Lantern.moon500} darkColor={Lantern.moon500} selectable>
              No development photo snapshot yet. Capture another photo to populate the full JSON trace.
            </ThemedText>
          </View>
        )}
        <ThemedText style={styles.summary} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
          {memories.length} classified memories for {selectedDay?.kind === 'day' ? selectedDay.isoDate : 'the selected day'} · cloud {cloudIntelligenceEnabled ? 'opted in for notes' : 'off'}
        </ThemedText>
        {personalEntities.length > 0 ? (
          <ThemedText style={styles.summary} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
            Local context: {personalEntities.map((entity) => entity.displayName ?? `${entity.relationship ?? entity.kind} (${entity.subrole ?? entity.kind})`).join(' · ')}
          </ThemedText>
        ) : null}
        {memories.map((memory) => (
          <View key={memory.id} style={styles.card}>
            <View style={styles.headingRow}>
              <ThemedText style={styles.title} lightColor={Lantern.moon50} darkColor={Lantern.moon50} selectable>
                {memory.dominantDomain}
              </ThemedText>
              <ThemedText style={styles.provider} lightColor={Lantern.ember300} darkColor={Lantern.ember300} selectable>
                {memory.sourceType}
              </ThemedText>
            </View>
            <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              Observed: {memory.observations.map((item) => `${item.provider}:${item.value} ${Math.round(item.confidence * 100)}%`).join(' · ') || 'none'}
            </ThemedText>
            <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              Facets: {memory.facets.map((item) => `${item.key}=${item.value}${item.confirmed ? ' ✓' : ''}${item.sensitive ? ' private' : ''}`).join(' · ') || 'none'}
            </ThemedText>
            <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              Qualities: {memory.qualities.map((quality) => `${quality.qualityId} ${Math.round(quality.score * 100)}% ${quality.centrality}/${quality.status} [${quality.sources.map((source) => source.provider).join('+') || 'manual'}]`).join(' | ') || 'none'}
            </ThemedText>
            {memory.photoAnalysis ? (
              <>
                <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
                  Representation: {memory.photoAnalysis.representation.kind} {Math.round(memory.photoAnalysis.representation.confidence * 100)}% ({memory.photoAnalysis.representation.reasons.join(', ')})
                </ThemedText>
                <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
                  Subjects: {memory.photoAnalysis.subjects.map((subject) => `${subject.role} ${subject.canonicalValue} ${Math.round(subject.score * 100)}%${subject.region ? ' boxed' : ''}`).join(' | ') || 'none'}
                </ThemedText>
                <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
                  OCR: {memory.photoAnalysis.selectedOcr.map((item) => `${item.purpose}:${item.text} ${Math.round(item.confidence * 100)}%`).join(' | ') || 'none'}
                </ThemedText>
                <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
                  Providers: {memory.photoAnalysis.providerRuns.map((run) => `${run.provider}:${run.status}${run.promptVersion ? `/${run.promptVersion}` : ''}`).join(' | ')}
                </ThemedText>
                <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
                  Alternatives: {memory.photoAnalysis.alternatives.map((item) => `${item.domain} ${Math.round(item.score * 100)}%`).join(' | ') || 'none'}
                </ThemedText>
                {memory.photoAnalysis.hierarchy ? (
                  <>
                    <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
                      Hierarchy: {memory.photoAnalysis.hierarchy.representation.kind} → {memory.photoAnalysis.hierarchy.container.kind}
                    </ThemedText>
                    <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
                      Paths: {memory.photoAnalysis.hierarchy.hypotheses.map((item) => `${item.path.join(' › ')} ${Math.round(item.confidence * 100)}%${item.contradictions.length ? ' ⚠' : ''}`).join(' | ') || 'none'}
                    </ThemedText>
                    <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
                      Ask next: {memory.photoAnalysis.hierarchy.unresolvedFacets.map((item) => `${item.key} ${Math.round(item.importance * item.uncertainty * 100)}%`).join(' | ') || 'nothing'}
                    </ThemedText>
                  </>
                ) : null}
              </>
            ) : null}
            <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              Quest matches: {questMatchesForMemory(memory.qualities).join(' | ') || 'none'}
            </ThemedText>
            <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              Assignments: {memory.assignments.map((item) => `${item.role} ${item.seedId} ${Math.round(item.score * 100)}%${item.confirmed ? ' confirmed' : ''} (${item.reasons.join(', ')})`).join(' · ') || 'none'}
            </ThemedText>
            <ThemedText style={styles.line} lightColor={Lantern.moon300} darkColor={Lantern.moon300} selectable>
              Overrides: {memory.confirmations.map((item) => `${item.promptId} → ${item.label}`).join(' · ') || 'none'}
            </ThemedText>
            <ThemedText style={styles.line} lightColor={Lantern.moon500} darkColor={Lantern.moon500} selectable>
              Prompt: {memory.promptState.status}{memory.promptState.graphId ? ` · ${memory.promptState.graphId}` : ''} · {memory.promptState.questionCount ?? memory.promptState.answeredNodeIds.length}/{memory.promptState.maxQuestions ?? 3}{memory.promptState.answeredNodeIds.length ? ` · path ${memory.promptState.answeredNodeIds.join(' → ')}` : ''}
            </ThemedText>
            <ThemedText style={styles.line} lightColor={Lantern.moon500} darkColor={Lantern.moon500} selectable>
              Question planner v{memory.promptState.plannerVersion ?? 1}: {memory.promptState.currentQuestionId ?? 'none'} · substantive {memory.promptState.questionCount ?? 0} · OCR checks {memory.promptState.microQuestionCount ?? 0}
            </ThemedText>
            {(memory.promptState.candidateTrace ?? []).map((candidate) => (
              <ThemedText key={candidate.questionId} style={styles.line} lightColor={candidate.eligible ? '#A8E2C6' : Lantern.moon500} darkColor={candidate.eligible ? '#A8E2C6' : Lantern.moon500} selectable>
                {candidate.eligible ? 'ELIGIBLE' : 'BLOCKED'} {candidate.questionId} · {Math.round(candidate.score * 100)}% · evidence {Math.round(candidate.components.evidenceSupport * 100)} · centrality {Math.round(candidate.components.centrality * 100)} · info {Math.round(candidate.components.informationGain * 100)}{candidate.blockers.length ? ` · ${candidate.blockers.join(', ')}` : ''}
              </ThemedText>
            ))}
          </View>
        ))}
        {memories.length === 0 ? (
          <View style={styles.empty}>
            <ThemedText lightColor={Lantern.moon500} darkColor={Lantern.moon500} selectable>
              Capture a photo, note, place, or movement answer to inspect its classification.
            </ThemedText>
          </View>
        ) : null}
      </ScrollView>
    </>
  );
}

function decisionColor(decision: 'ready' | 'possible' | 'no_match'): string {
  return decision === 'ready' ? '#A8E2C6' : decision === 'possible' ? '#F3B36A' : '#F08C8C';
}

function questMatchesForMemory(qualities: { qualityId: string; score: number; status: string }[]): string[] {
  return qualities.flatMap((quality) => {
    const thresholds = qualityThresholds(quality.qualityId);
    if (quality.status === 'rejected' || quality.score < thresholds.review) return [];
    const status = quality.score >= thresholds.ready || quality.status === 'confirmed' ? 'ready' : 'possible';
    return Object.values(QUEST_DEFINITIONS)
      .filter((quest) => quest.criteria.some((criterion) => criterion.fact === 'memory.qualities' && criterion.value === quality.qualityId))
      .map((quest) => `${quest.id} ${status}`);
  });
}

const styles = StyleSheet.create({
  content: { gap: 12, padding: 18, paddingBottom: 48 },
  summary: { fontSize: 13, fontWeight: '700' },
  card: {
    backgroundColor: 'rgba(20,17,31,0.92)',
    borderColor: 'rgba(255,255,255,0.12)',
    borderCurve: 'continuous',
    borderRadius: 20,
    borderWidth: 1,
    gap: 8,
    padding: 16,
  },
  lastPhotoCard: { borderColor: 'rgba(146,215,255,0.4)' },
  hatchDecisionCard: { borderColor: 'rgba(168,226,198,0.4)' },
  foundationReady: { borderColor: 'rgba(168,226,198,0.4)' },
  foundationWarning: { borderColor: 'rgba(243,179,106,0.55)' },
  photo: { width: '100%', aspectRatio: 1.4, borderRadius: 14, backgroundColor: 'rgba(255,255,255,0.06)' },
  questDecision: { gap: 4, padding: 10, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.05)' },
  decisionTitle: { fontSize: 14, fontWeight: '900', textTransform: 'capitalize' },
  shareButton: { alignSelf: 'flex-start', borderRadius: 10, paddingHorizontal: 12, paddingVertical: 8, backgroundColor: '#92D7FF' },
  shareLabel: { fontSize: 12.5, fontWeight: '900' },
  traceActions: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  disabledButton: { opacity: 0.4 },
  json: { fontFamily: 'monospace', fontSize: 10.5, lineHeight: 15 },
  headingRow: { alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between' },
  toggleRow: { alignItems: 'center', borderTopColor: 'rgba(255,255,255,0.1)', borderTopWidth: 1, flexDirection: 'row', gap: 14, marginTop: 4, paddingTop: 12 },
  toggleCopy: { flex: 1, gap: 3 },
  toggleTitle: { fontSize: 14, fontWeight: '800' },
  title: { fontSize: 18, fontWeight: '800', textTransform: 'capitalize' },
  provider: { fontSize: 11, fontWeight: '800', textTransform: 'uppercase' },
  line: { fontSize: 12.5, lineHeight: 18 },
  empty: { alignItems: 'center', paddingVertical: 40 },
});
